/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Challenge;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import static jdbcsample.JDBCSample.convertToDateFromString;

/**
 *
 * @author ASUS
 */
public class Driver {
    
    public static void AddMhs(Connection con) throws SQLException{
        jdbcsample.TMahasiswa objMhs = new jdbcsample.TMahasiswa();
        System.out.print("Masukkan NIM: "); objMhs.setNim(new Scanner(System.in).nextLine());
        System.out.print("Masukkan nama mahasiswa: "); objMhs.setNama(new Scanner(System.in).nextLine());       
        System.out.print("Masukkan DOB: ");
        objMhs.setDob(convertToDateFromString(new Scanner(System.in).nextLine(), "dd/MM/yyyy"));;
        String _sql = "INSERT INTO TMahasiswa(NIM, NAMA< DOB, ENAIL) VALUES(?,?,?,?)";  
        PreparedStatement pStmnt = con.prepareStatement(_sql);
        pStmnt.setString(1, objMhs.getNim());
        pStmnt.setString(2, objMhs.getNama());
        pStmnt.setDate(3, (java.sql.Date) objMhs.getDob());
        pStmnt.setString(4, objMhs.getEmail());
        
        int response = pStmnt.executeUpdate();
        if(response > 0) System.out.println("Success save data");
        else System.out.println("Unable to save the data");
        con.close();
    }
    
    public static void AddMatkul(Connection con){
        Challenge.TMataKuliah objMatkul = new Challenge.TMataKuliah();
        System.out.print("Masukkan ID Matkul: "); objMatkul.setID(new Scanner(System.in).nextLine());`
        System.out.print("Masukkan nama mahasiswa: "); objMatkul.setNAMA_MATKUL(new Scanner(System.in).nextLine());       
        System.out.print("Masukkan DOB: ");
 
        String _sql = "INSERT INTO TMataKuliah(ID, NAMA_MATKUL) VALUES(?,?)";  
        PreparedStatement pStmnt = con.prepareStatement(_sql);
        pStmnt.setString(1, objMatkul.getID());
        pStmnt.setString(2, objMatkul.getNAMA_MATKUL());

        int response = pStmnt.executeUpdate();
        if(response > 0) System.out.println("Success save data");
        else System.out.println("Unable to save the data");
        con.close();
    }
    
    public static void printMhs(Connection con){
        Challenge.TmhsMatkul objmhsMatkul = new Challenge.TmhsMatkul();
        String _sql = "SELECT * FROM TmhsMatkul";
        PreparedStatement ps = con.prepareStatement(_sql);
        
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            objmhsMatkul.setID(rs.getString("ID"));
            objmhsMatkul.setNIM(rs.getString("NIM"));
        }
        
        
        con.close();
    }
    public static void main(String[] args) {
        try {
            String className = "com.mysql.cj.jdbc.Driver";
            Class.forName(className);
            System.out.println("Driver loaded successfully");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/PROFIL", "root", "");
            
            if(con.isClosed()) System.out.println("Connection is closed");
            else {
                System.out.println("1. Tambah data Mahasiswa");
                System.out.println("2. Tambah data Mata Kuliah");
                System.out.println("3. Cetak Data Mahasiswa");
                System.out.print("Masukkan pilihan");
                int pilih = new Scanner(System.in).nextInt();
                if(pilih == 1){
                    AddMhs(con);
                }
                if(pilih == 2){
                    AddMatkul(con);
                }
                if(pilih == 3){
                    printMhs(con);
                }
                
            }
            
        } catch(Exception ex){
            
        }
    }
}
