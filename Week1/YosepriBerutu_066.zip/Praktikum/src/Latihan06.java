/*
Nama : Yosepri Disyandro Berutu
NIM : 11318066
Tanggal : 13 September 2019
 */
public class Latihan06 {
    public static void main(String[] args){
        int myArray[] = new int[3];

        myArray[0] = 1;
        myArray[1] = 2;
        myArray[2] = 3;

        System.out.println(myArray[0] +", " + myArray[1] + ", " + myArray[2]);
    }
}
