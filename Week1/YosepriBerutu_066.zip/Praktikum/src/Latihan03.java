/*
Nama : Yosepri Disyandro Berutu
NIM : 11318066
Tanggal : 13 September 2019
 */
public class Latihan03 {
    public static void main(String[] args){
        System.out.println("Range Byte: " + Byte.MIN_VALUE + "until" + Byte.MAX_VALUE);
        System.out.println("Range Byte: " + Integer.MIN_VALUE + "until" + Integer.MAX_VALUE);
        System.out.println("Range Byte: " + Float.MIN_VALUE + "until" + Float.MAX_VALUE);
        System.out.println("Range Byte: " + Double.MIN_VALUE + "until" + Double.MAX_VALUE);
    }
}
