/*
Nama : Yosepri Disyandro Berutu
NIM : 11318066
Tanggal : 13 September 2019
 */

public class Latihan02
{
    public static void main(String[] args){
        Latihan02.cetak();
    }

    public  static void cetak(){
        System.out.println("Hello, world! From method cetak");
    }
}
