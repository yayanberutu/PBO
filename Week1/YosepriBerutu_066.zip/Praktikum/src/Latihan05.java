/*
Nama : Yosepri Disyandro Berutu
NIM : 11318066
Tanggal : 13 September 2019
 */
public class Latihan05 {
    public static void main(String[] args){
        final float PI = 3.14f;
        float a,r = 10.8f;
        a = PI * r * r;
        System.out.println(a);
    }
}
