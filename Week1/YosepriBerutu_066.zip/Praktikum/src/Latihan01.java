/*
Nama : Yosepri Disyandro Berutu
NIM : 11318066
Tanggal : 13 September 2019
 */
import java.lang.*;

public class Latihan01 {
    public static void main(String[] args){
        System.out.println("Hello World!");
    }
}
