/*
Nama : Yosepri Disyandro Berutu
NIM : 11318066
Tanggal : 13 September 2019
 */
public class Latihan07 {
    public static void main(String[] args){
        short a = 5;
        int b;
        b = a; //otomatis di casting tipe datanya
        float c = 23.123456f;
        int d;
        d = (int) c;
        System.out.println(d);
        //fractional component sudah dihilangkan
    }
}
