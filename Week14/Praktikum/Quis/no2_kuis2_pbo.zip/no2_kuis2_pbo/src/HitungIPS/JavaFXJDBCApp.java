/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HitungIPS;

import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.event.*;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import javafx.beans.value.ChangeListener;


/**
 *
 * @author Yosepri Berutu
 */
public class JavaFXJDBCApp extends Application{
    public static List<TMahasiswa> listMahasiswa;
    public static List<TMataKuliah> listMataKuliah;
    public static List<TMkMhs> listKrs;

    @Override
    public void start(Stage primaryStage) throws Exception {
        TabPane tp = new TabPane();
        Tab tab3 = new Tab("Cari Mahasiswa");
        
        tp.getTabs().addAll(tab3);
        GridPane grdKrs = new GridPane();
        
        tab3.setContent(grdKrs);

        Label lblNama = new Label("Nama Mahasiswa");
        TextField txtNama = new TextField();
        Label lblNim = new Label("NIM");
        TextField txtNim = new TextField();
        Label lblDob = new Label("Date of Birth");
        DatePicker dpDob = new DatePicker(LocalDate.now());
        dpDob.setEditable(false);

        Label lblIdMatkul = new Label("Kode Mata Kuliah");
        TextField txtIdMatkul = new TextField();
        Label lblNamaMatkul = new Label("Nama Mata Kuliah");
        TextField txtNamaMatkul = new TextField(); 
        Label lblJlhSks = new Label("Jumlah SKS");
        TextField txtJlhSks = new TextField(); 
        Label lblInfoTab2 = new Label();
        lblInfoTab2.setStyle("-fx-font-style: italic");
        /*
        
        
        IPS
       
        */
        Label okMatkul = new Label("0");
        Label okMhs = new Label("0");
        okMatkul.setVisible(false);
        okMhs.setVisible(false);
        
        Button btnSaveTab3 = new Button("Simpan data KRS");
        btnSaveTab3.setDisable(true);
        
        Label lblInfoTab3 = new Label();
        Label lblIdMatkulKrs = new Label("Kode Mata Kuliah");
        Label lblNamaMatkulKrs = new Label("Nama MataKuliah");
        lblNamaMatkulKrs.setTextFill(Color.BLACK);
        Label lblKodeMatkulKrs = new Label("Kode Matakuliah");
        Label lblSksMatkulKrs = new Label("SKS");
        Label lblNilaiMatkulKrs = new Label("Nilai");
        Label lblGradeMatkulKrs = new Label("Grade");
        Label lblNamaMatkul1 = new Label("Nama Mata Kuliah");
        TextField txtIdMatkulKrs = new TextField();
        
        Label lblNimKrs = new Label("NIM");
        Label lblNamaMhsKrs = new Label("Tidak Ditemukan");
        lblNamaMhsKrs.setTextFill(Color.RED);
        Label lblNama1 = new Label("NAMA");
        TextField txtNimKrs = new TextField();
        
        txtIdMatkulKrs.textProperty().addListener((ObservableValue<? extends String>
                    observable,String oldValue,String newValue) -> {
                    Object objMatkul = GeneralUtils.findMataKuliah(newValue,listMataKuliah);
                    
                if(objMatkul == null){
                    lblNamaMatkul.setTextFill(Color.RED);
                    lblNamaMatkul.setText("Tidak Ditemukan");
                    okMatkul.setText("0");
                }
                else{
                    lblNamaMatkulKrs.setTextFill(Color.BLUE);
                    lblNamaMatkulKrs.setText(((TMataKuliah)objMatkul).getNamaMatkul());
                    okMatkul.setText("1");
                }
                if(okMatkul.getText().equals("0") || okMhs.getText().equals("0"))
                    btnSaveTab3.setDisable(true);
                else
                    btnSaveTab3.setDisable(false);
            });
        
        txtNimKrs.textProperty().addListener((ObservableValue<? extends String>
                    observable,String oldValue,String newValue) -> {
                    Object objMhs = GeneralUtils.findMahasiswa(newValue,listMahasiswa);
                    
                if(objMhs == null){
                    lblNamaMhsKrs.setTextFill(Color.RED);
                    lblNamaMhsKrs.setText("Tidak Ditemukan");
                    okMhs.setText("0");
                }
                else{
                    lblNamaMhsKrs.setTextFill(Color.BLUE);
                    lblNamaMhsKrs.setText(((TMahasiswa)objMhs).getNama());
                    okMhs.setText("1");
                }
                if(okMatkul.getText().equals("0") || okMhs.getText().equals("0"))
                    btnSaveTab3.setDisable(true);
                else
                    btnSaveTab3.setDisable(false);
            });
        ColumnConstraints cons1 = new ColumnConstraints();
        ColumnConstraints cons2 = new ColumnConstraints();
        cons1.setPercentWidth(30);
        cons2.setPercentWidth(70);
        grdKrs.getColumnConstraints().addAll(cons1,cons2);
//        grdKrs.add(lblIdMatkulKrs, 0, 2); 
//        grdKrs.add(txtIdMatkulKrs,1,2);
        grdKrs.add(lblNamaMatkul1,0,3);
        
        grdKrs.add(lblNamaMatkulKrs,1,3);
        grdKrs.add(lblKodeMatkulKrs, 2, 3);
        grdKrs.add(lblSksMatkulKrs,3,3);
        grdKrs.add(lblNilaiMatkulKrs, 4, 3);
        grdKrs.add(lblGradeMatkulKrs,5,3);
        
        grdKrs.add(lblNimKrs,0,0);
        grdKrs.add(txtNimKrs,1,0);
        grdKrs.add(lblNama1,0,1); 
        grdKrs.add(lblNamaMhsKrs,1,1); 

        
        lblNamaMatkulKrs.setStyle("-fx-font-style: italic");
        lblNamaMhsKrs.setStyle("-fx-font-style: italic");
        lblInfoTab3.setStyle("-fx-font-style: italic");
        

            Scene scene = new Scene(tp,750,300);
            primaryStage.setTitle("Aplikasi Pencarian IPS Mahasiswa IT-DEL");
            primaryStage.setScene(scene);
            primaryStage.show();
        }
        public static void main(String[] args) throws SQLException,ClassNotFoundException{
            loadAllData();
            launch(args);
        }
        
        public static void loadAllData() throws SQLException,ClassNotFoundException{
            listMahasiswa = DBUtils.getAllMahasiswa();
            listMataKuliah = DBUtils.getAllMataKuliah();
            listKrs = DBUtils.getAllKrs();
        }
}
