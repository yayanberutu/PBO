/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Challenge;

/**
 *
 * @author Yosepri Disyandro Berutu
 */
public class TmhsMatkul {
    private String _ID, _NIM;
    private float nilai;

    public float getNilai() {
        return nilai;
    }

    public void setNilai(float nilai) {
        this.nilai = nilai;
    }
    
    
    public String getID() {
        return _ID;
    }

    public void setID(String _ID) {
        this._ID = _ID;
    }

    public String getNIM() {
        return _NIM;
    }

    public void setNIM(String _NIM) {
        this._NIM = _NIM;
    }
    
    
}
