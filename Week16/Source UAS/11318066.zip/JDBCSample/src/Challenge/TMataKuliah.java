/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Challenge;

/**
 *
 * @author Yosepri Disyandro Berutu
 */
public class TMataKuliah {
    private String _ID, _NAMA_MATKUL;
    private int _SKS;

    public String getID() {
        return _ID;
    }

    public void setID(String _ID) {
        this._ID = _ID;
    }

    public String getNAMA_MATKUL() {
        return _NAMA_MATKUL;
    }

    public void setNAMA_MATKUL(String _NAMA_MATKUL) {
        this._NAMA_MATKUL = _NAMA_MATKUL;
    }

    public int getSKS() {
        return _SKS;
    }

    public void setSKS(int _SKS) {
        this._SKS = _SKS;
    }
    
    
    
}
