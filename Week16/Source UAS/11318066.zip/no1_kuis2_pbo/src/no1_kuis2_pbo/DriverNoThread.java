/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package no1_kuis2_pbo;

/**
 *
 * @author Sarah Christine (11318058)
 */
public class DriverNoThread {
    public static void main(String[] args) {
        new ClassA("Objek A").run();
        new ClassB("Objek B").run();
    }
}
