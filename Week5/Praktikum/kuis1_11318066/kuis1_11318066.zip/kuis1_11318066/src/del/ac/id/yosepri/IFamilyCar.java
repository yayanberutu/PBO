package del.ac.id.yosepri;

public interface IFamilyCar {
    public void setModeCar(String mode);
    public void designCarBasedOnMode();
}
