package tugas2;

public interface IAnimal {
    public static final int FURRY = 0;
    public static final int SCALY = 1;

    public void eat();
    public void speak();
}
