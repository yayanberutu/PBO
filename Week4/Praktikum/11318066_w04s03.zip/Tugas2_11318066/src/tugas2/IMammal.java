package tugas2;

public interface IMammal {

    public void shedFun();
}
