package tugas2;

public class GoldFish extends Pet{

    public GoldFish(String name, int age){

    }

    public void eat(){
        System.out.println("Ikan makan pelet");
    }
    public void speak(){
        System.out.println("Guduk guduk");
    }

    public void swim(){
        System.out.println("Ikan berenang");
    }

}
