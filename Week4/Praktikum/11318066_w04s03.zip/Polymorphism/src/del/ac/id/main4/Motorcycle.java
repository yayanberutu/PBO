package del.ac.id.main4;


public class Motorcycle extends MovingObject {
    @Override
    void caraMerakitObjekBergerak() {
        System.out.print("Cara merakit sepeda motor adalah pasang dua buah roda");
    }
}
