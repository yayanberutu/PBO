package del.ac.id.main4;

public interface IVehicle {
    float decreaseSpeed();
    float decreaseSpeed(String brakeMechanism);
}
