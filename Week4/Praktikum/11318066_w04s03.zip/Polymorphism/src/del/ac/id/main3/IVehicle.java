package del.ac.id.main3;

public interface IVehicle {
    float decreaseSpeed();
    float decreaseSpeed(String brakeMechanism);
}
